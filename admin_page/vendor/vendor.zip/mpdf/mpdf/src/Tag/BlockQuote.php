<?php

namespace Mpdf\Tag;

class BlockQuote extends BlockTag
{


}
